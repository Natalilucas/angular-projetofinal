export interface Tutores {
  id?: string,
  nome: string,
  telemovel: string,
  email: string
}
