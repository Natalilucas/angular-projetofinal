export interface Animais{
  id?: string,
  nome: string,
  especie: string,
  raca: string,
  sexo: string,
  dataNascimento: string,
  tutorId: string
}
